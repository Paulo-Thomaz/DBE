<?php

require "conexao.php";

$id = $_GET['id'];
$sql = "delete FROM produtos WHERE id=$id;";
if($conn->query($sql) == true){
    header("Location: adimin.php");
    exit();
}else{
    header("Location: cadastrar-usuario.php?erro=2");
    exit();
}

?>
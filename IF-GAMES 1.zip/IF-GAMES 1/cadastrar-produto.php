<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style3.css">
    <title>Cadastro de Produtos</title>
</head>
<body>
    <main>
        <div class="c tamanho">
            <div class="cc">
                <h1>IFgames</h1>
                <br>
                <form action="processar_cadastro_produto.php" method="post">
                    <label>
                        <input type="text" required placeholder="Nome do Item" name="nome">
                    </label><br><br>
                    <label>
                        <input type="text" required placeholder="Gênero" name="tipo">
                    </label><br><br>
                    <label>
                        <input type="text" required placeholder="Descrição :" name="descricao">
                    </label>
                    <br><br>
                    <label>
                        <input type="number" required placeholder="Avaliação 0 a 5" name="avaliacao">
                    </label>
                    <br><br>
                    <label>
                        <input type="number" required placeholder="Preço" name="preco">
                    </label>
                    <br><br>
                    <label for="imagem">Envie uma imagem do produto</label>
                        <input type="file" name="imagem" accept="image/*" id="imagem" placeholder="Envie uma imagem">
                    <div>
                        <hr>
                        <button type="submit" class="none">Cadastrar</button>
                    </div>
                </form>
            </div>
        </div>
    </main>
</body>
</html>

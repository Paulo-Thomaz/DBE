<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="js/1.js" defer></script>
    <title>Cadastro</title>
</head>
<body>
    <main>
        <div class="c , tamanho">
            <div class="img tamanho">
                <img src="assets/img/logo.png" alt="controle de video game">
            </div>
            <div class="cc">
                <h1>IFgames | cadastro</h1>
                <br>
                <form action="processar_cadastro.php" method="post">
                    <label>
                        <input type="text" required placeholder="Nome :" name="nome">
                    </label><br><br>
                    <label>
                        <input type="email" required placeholder=" Email :" name="email">
                    </label><br><br>
                    <label>
                        <input type="text" required placeholder="Senha :" name="senha">
                    </label>
                    <br><br>
                    <label>
                        <input type="text" required placeholder="Confirmar Senha :" name="confirmarSenha">
                        <?php
                        if (isset($_GET['erro'])) {
                            echo "senha e confirmar senha não são iguais";
                        }
                        ?>
                    </label>
                    <br><br>
                    <div>
                        <hr>
                        <button type="submit" class="none">cadastrar</button> |
                        <button type="button" class="none" onclick="window.location.href = 'login.html';">login</button>
                    </div>
                </form>
            </div>
        </div>
    </main>
</body>
</html>

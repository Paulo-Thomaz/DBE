<?php
// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conectar ao banco de dados (substitua com suas próprias credenciais)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "cafebistro_phpoo";

    $nome = $_POST["nome"];
    $tipo = $_POST["tipo"];
    $descricao = $_POST["descricao"];
    $preco = $_POST["preco"];
    $avaliacao = $_POST["avaliacao"];
    $id = $_POST["id"];
    $imagemm = $_POST["imagemm"];

    $conn = new mysqli($servername, $username, $password, $dbname);

    if (isset($_FILES["imagem"])) {

        $diretorio_destino = "img/"; // Pasta onde as imagens serão salvas
        $nome_arquivo = basename($_FILES["imagem/"]["name"]); // Nome do arquivo enviado
        $caminho_arquivo = $diretorio_destino . $nome_arquivo; // Caminho completo do arquivo no servidor
        $imagem = $caminho_arquivo;
        // Verifica se o arquivo é uma imagem
        $tipo_arquivo = strtolower(pathinfo($caminho_arquivo, PATHINFO_EXTENSION));
        $tipos_permitidos = array("jpg", "jpeg", "png", "gif");
    
        if (in_array($tipo_arquivo, $tipos_permitidos)) {
            // Tenta mover o arquivo temporário para o destino
            if (move_uploaded_file($_FILES["imagem"]["tmp_name"], $caminho_arquivo)) {
    
                // Inserir os dados na tabela 'produtos' mesmo quando a imagem não foi cadastrada
                $sql = "INSERT INTO produtos (nome, tipo, descricao, avaliacao, preco, imagem, id) VALUES 
                ('$nome', '$tipo', '$descricao', $avaliacao, '$preco', '$imagem', '$id')";
    
                if ($conn->query($sql) === TRUE) {
                    header("Location: adimin.php");
                    exit();
                } else {
                    header("Location: cadastrar-produto.php?erro=1");
                    exit();
                }
                $conn->close();
            } else {
                echo "Erro ao realizar o upload da imagem.";
            }
        } else {
            echo "Apenas arquivos do tipo JPG, JPEG, PNG e GIF são permitidos.";
        }
    } else {
        // Inserir os dados na tabela 'produtos' mesmo quando a imagem não foi cadastrada
        $sql = "INSERT INTO produtos (nome, tipo, descricao, avaliacao, preco, imagem, id) VALUES 
        ('$nome', '$tipo', '$descricao', '$avaliacao', '$preco', '$imagem', '$id')";
    
        if ($conn->query($sql) === TRUE) {
            header("Location: adimin.php");
            exit();
        } else {
            header("Location: cadastrar-produto.php?erro=1");
            exit();
        }
        $conn->close();
    }
}
?>
